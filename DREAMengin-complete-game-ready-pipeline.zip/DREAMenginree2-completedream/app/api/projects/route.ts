import { createServerClient } from '@/supabase/server/serverClient';
import { safeGetUser } from '@/supabase/client/safeGetUser';
import type { Database } from '@/types/supabase';
import type { SupabaseClient } from '@supabase/supabase-js';
import { NextRequest, NextResponse } from 'next/server';
import { toErrorMessage } from '@/utils/index';


export async function GET(req: NextRequest): Promise<NextResponse> {
  const supabase = (await createServerClient()) as SupabaseClient<Database>;
  const user = await safeGetUser(supabase);

  if (!user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const { searchParams } = new URL(req.url);
  const ownerId = searchParams.get('owner_id');
  const visibility = searchParams.get('visibility') || 'all';
  const projectId = searchParams.get('id');

  
  if (projectId) {
    const { data: project, error } = await supabase
      .from('projects')
      .select(`
        *,
        profiles!inner(id, handle, display_name, avatar_url)
      `)
      .eq('id', projectId)
      .single();

    if (error) {
      return NextResponse.json({ error: toErrorMessage(error) }, { status: 500 });
    }

    
    if (project.visibility !== 'public' && project.user_id !== user.id) {
      return NextResponse.json({ error: 'Access denied' }, { status: 403 });
    }

    return NextResponse.json({ project });
  }

  
  let query = supabase
    .from('projects')
    .select(`
      *,
      profiles!inner(id, handle, display_name, avatar_url)
    `)
    .order('created_at', { ascending: false });

  if (ownerId) {
    query = query.eq('user_id', ownerId);
    if (ownerId !== user.id) {
      query = query.eq('visibility', 'public');
    }
  } else if (visibility === 'public') {
    query = query.eq('visibility', 'public');
  } else {
    query = query.or(`visibility.eq.public,user_id.eq.${user.id}`);
  }

  const { data: projects, error } = await query;

  if (error) {
    return NextResponse.json({ error: toErrorMessage(error) }, { status: 500 });
  }

  return NextResponse.json({ projects });
}


export async function POST(req: NextRequest): Promise<NextResponse> {
  const supabase = (await createServerClient()) as SupabaseClient<Database>;
  const user = await safeGetUser(supabase);

  if (!user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const body = await req.json().catch(() => ({})) as {
    title?: string;
    description?: string;
    visibility?: string;
  };
  const { title, description, visibility = 'private' } = body;

  if (!title || title.trim().length === 0) {
    return NextResponse.json({ error: 'Title is required' }, { status: 400 });
  }

  const { data: project, error } = await supabase
    .from('projects')
    .insert({
      user_id: user.id,
      title: title.trim(),
      description: description?.trim() || null,
      visibility,
      status: 'active',
    })
    .select(`
      *,
      profiles!inner(id, handle, display_name, avatar_url)
    `)
    .single();

  if (error) {
    return NextResponse.json({ error: toErrorMessage(error) }, { status: 500 });
  }

  return NextResponse.json({ project }, { status: 201 });
}


export async function PUT(req: NextRequest): Promise<NextResponse> {
  const supabase = (await createServerClient()) as SupabaseClient<Database>;
  const user = await safeGetUser(supabase);

  if (!user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const body = await req.json().catch(() => ({})) as {
    id?: string;
    title?: string;
    description?: string;
    visibility?: string;
  };
  const { id, title, description, visibility } = body;

  if (!id) {
    return NextResponse.json({ error: 'Project ID is required' }, { status: 400 });
  }

  const updateData: Record<string, unknown> = {
    updated_at: new Date().toISOString(),
  };

  if (title !== undefined) updateData.title = title.trim();
  if (description !== undefined) updateData.description = description?.trim();
  if (visibility !== undefined) updateData.visibility = visibility;

  const { data: project, error } = await supabase
    .from('projects')
    .update(updateData as never)
    .eq('id', id)
    .eq('user_id', user.id)
    .select()
    .single();

  if (error) {
    return NextResponse.json({ error: toErrorMessage(error) }, { status: 500 });
  }

  return NextResponse.json({ project });
}


export async function DELETE(req: NextRequest): Promise<NextResponse> {
  const supabase = (await createServerClient()) as SupabaseClient<Database>;
  const user = await safeGetUser(supabase);

  if (!user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const { searchParams } = new URL(req.url);
  const id = searchParams.get('id');

  if (!id) {
    return NextResponse.json({ error: 'Project ID is required' }, { status: 400 });
  }

  const { error } = await supabase
    .from('projects')
    .delete()
    .eq('id', id)
    .eq('user_id', user.id);

  if (error) {
    return NextResponse.json({ error: toErrorMessage(error) }, { status: 500 });
  }

  return NextResponse.json({ success: true });
}
