import { jsonApiError } from '@/engine/api/route';
import { createServerClient } from '@/supabase/server/serverClient';
import { safeGetUser } from '@/supabase/client/safeGetUser';
import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { toErrorMessage } from '@/utils/index';






const BlockBodySchema = z.object({
  blocked_id: z.string().uuid(),
});


export async function GET( ): Promise<NextResponse> {
  const supabase = await createServerClient();
  const user = await safeGetUser(supabase);
  if (!user) return jsonApiError(401, 'NOT_AUTHENTICATED', 'You must be signed in.');

  const { data, error } = await supabase
    .from('user_blocks')
    .select('id, blocked_id, created_at')
    .eq('blocker_id', user.id)
    .order('created_at', { ascending: false });

  if (error) return jsonApiError(500, 'DB_ERROR', toErrorMessage(error));
  return NextResponse.json({ blocks: data ?? [] });
}


export async function POST(req: NextRequest): Promise<NextResponse> {
  const supabase = await createServerClient();
  const user = await safeGetUser(supabase);
  if (!user) return jsonApiError(401, 'NOT_AUTHENTICATED', 'You must be signed in.');

  let body: unknown;
  try { body = await req.json(); } catch { return jsonApiError(400, 'BAD_JSON', 'Body must be valid JSON.'); }

  const parsed = BlockBodySchema.safeParse(body);
  if (!parsed.success) return jsonApiError(400, 'VALIDATION_ERROR', 'blocked_id must be a valid UUID.');

  const { blocked_id } = parsed.data;
  if (blocked_id === user.id) return jsonApiError(400, 'SELF_BLOCK', 'You cannot block yourself.');

  const { data, error } = await supabase
    .from('user_blocks')
    .upsert(
      { blocker_id: user.id, blocked_id },
      { onConflict: 'blocker_id,blocked_id', ignoreDuplicates: true },
    )
    .select('id, blocked_id, created_at')
    .single();

  if (error) return jsonApiError(500, 'DB_ERROR', toErrorMessage(error));
  return NextResponse.json({ ok: true, block: data }, { status: 201 });
}


export async function DELETE(req: NextRequest): Promise<NextResponse> {
  const supabase = await createServerClient();
  const user = await safeGetUser(supabase);
  if (!user) return jsonApiError(401, 'NOT_AUTHENTICATED', 'You must be signed in.');

  const blocked_id = req.nextUrl.searchParams.get('blocked_id');
  if (!blocked_id || !/^[0-9a-f-]{36}$/.test(blocked_id)) {
    return jsonApiError(400, 'MISSING_PARAM', 'blocked_id query param is required and must be a valid UUID.');
  }

  const { error } = await supabase
    .from('user_blocks')
    .delete()
    .eq('blocker_id', user.id)
    .eq('blocked_id', blocked_id);

  if (error) return jsonApiError(500, 'DB_ERROR', toErrorMessage(error));
  return NextResponse.json({ ok: true });
}
