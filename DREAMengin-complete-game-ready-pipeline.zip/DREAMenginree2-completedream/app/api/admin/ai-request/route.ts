import { createServerClient } from '@/supabase/server/serverClient';
import { safeGetUser } from '@/supabase/client/safeGetUser';
import { redirect } from 'next/navigation';
import { NextResponse } from 'next/server';

export async function POST(request: Request ): Promise<NextResponse> {
  const supabase = await createServerClient();
  const user = await safeGetUser(supabase);

  if (!user) {
    return redirect('/login');
  }

  const formData = await request.formData();
  const prompt = formData.get('prompt') as string;

  
  await supabase
    .from('admin_audit_log')
    .insert({
      actor_id: user.id,
      action: 'ai_update_request',
      details: { prompt, status: 'pending' }
    });

  return redirect('/idari-console');
}

