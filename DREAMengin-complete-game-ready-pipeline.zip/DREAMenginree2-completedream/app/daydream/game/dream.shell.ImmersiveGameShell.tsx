'use client';

import GameRemote from '@/components/games/dream.remote.GameRemote';
import GameRuntime from '@/engins/gameengin/GameRuntime';
import type { GameCartridge, GravityPreset } from '@/engins/gameengin/cartridge';
import { loadCartridge } from '@/engins/gameengin/cartridges/loaders';
import { CARTRIDGE_MANIFEST } from '@/engins/gameengin/cartridges/manifest';
import {
    buildGameLaunchHref,
    DEFAULT_GAME_ID,
    resolveGameLaunchId,
} from '@/engins/gameengin/games/navigation';
import { useRouter, useSearchParams } from 'next/navigation';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { toErrorMessage } from '@/utils/index';





const BOOT_KEYFRAMES = `
@keyframes de-hex-pulse {
  0%, 100% { opacity: 0.45; transform: scale(1); }
  50%       { opacity: 1;    transform: scale(1.07); }
}
@keyframes de-glow-ring-a {
  0%, 100% { opacity: 0.18; transform: scale(1); }
  50%       { opacity: 0.65; transform: scale(1.18); }
}
@keyframes de-glow-ring-b {
  0%, 100% { opacity: 0.10; transform: scale(1); }
  50%       { opacity: 0.40; transform: scale(1.12); }
}
@keyframes de-sweep-in {
  from { opacity: 0; transform: translateX(56px); }
  to   { opacity: 1; transform: translateX(0); }
}
@keyframes de-sweep-in-sub {
  from { opacity: 0; transform: translateX(38px); }
  to   { opacity: 1; transform: translateX(0); }
}
@keyframes de-emoji-pop {
  0%  { opacity: 0; transform: scale(0.4); }
  70% { transform: scale(1.12); }
  100%{ opacity: 1; transform: scale(1); }
}
@keyframes de-fade-in {
  from { opacity: 0; }
  to   { opacity: 1; }
}
@keyframes de-blink {
  0%, 100% { opacity: 1; }
  50%       { opacity: 0; }
}
@keyframes de-boot-fade-out {
  from { opacity: 1; }
  to   { opacity: 0; pointer-events: none; }
}
`;

const DEFAULT_HUD_BOTTOM             = '175px';
const MIN_STAGE_BOTTOM_CLEARANCE     = 'clamp(80px, 22dvh, 38dvh)';
const LANDSCAPE_MIN_STAGE_BOTTOM     = 'clamp(56px, 14dvh, 24dvh)';

export default function ImmersiveGameShell() {
  const router       = useRouter();
  const searchParams = useSearchParams();
  const rootRef      = useRef<HTMLDivElement>(null);

  const gameId = resolveGameLaunchId(
    searchParams.get('game'),
    CARTRIDGE_MANIFEST.map((c) => c.id),
    DEFAULT_GAME_ID,
  );
  const game = useMemo(
    () => CARTRIDGE_MANIFEST.find((c) => c.id === gameId) ?? CARTRIDGE_MANIFEST[0],
    [gameId],
  );

  const [cartridge, setCartridge] = useState<GameCartridge | null>(null);
  const [cartridgeError, setCartridgeError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    setCartridge(null);
    setCartridgeError(null);
    loadCartridge(gameId)
      .then((c) => { if (!cancelled) setCartridge(c); })
      .catch((err: unknown) => {
        if (!cancelled) {
          setCartridgeError(err instanceof Error ? toErrorMessage(err) : 'Failed to load cartridge.');
        }
      });
    return () => { cancelled = true; };
  }, [gameId]);

  const [bootPhase, setBootPhase] = useState<1 | 2 | 3 | 4>(1);
  const [fadingOut, setFadingOut] = useState(false);
  const [bootDone,  setBootDone]  = useState(false);

  const [isLandscape, setIsLandscape] = useState(() =>
    typeof window !== 'undefined' && window.innerWidth > window.innerHeight,
  );
  useEffect(() => {
    const mql = window.matchMedia('(orientation: landscape)');
    const handler = (e: MediaQueryListEvent) => setIsLandscape(e.matches);
    mql.addEventListener('change', handler);
    setIsLandscape(mql.matches);
    return () => mql.removeEventListener('change', handler);
  }, []);

  useEffect(() => {
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const footer = document.querySelector('footer') as HTMLElement | null;
    const prevFooterDisplay = footer?.style.display;
    if (footer) footer.style.display = 'none';
    return () => {
      document.body.style.overflow = prevOverflow;
      if (footer) footer.style.display = prevFooterDisplay ?? '';
    };
  }, []);

  useEffect(() => {
    if (typeof document === 'undefined') return;
    const id = 'de-boot-keyframes';
    if (!document.getElementById(id)) {
      const style = document.createElement('style');
      style.id = id;
      style.textContent = BOOT_KEYFRAMES;
      document.head.appendChild(style);
    }
  }, []);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('de:games:last-launch', game.id);
    }
  }, [game.id]);

  useEffect(() => {
    setBootPhase(1);
    setFadingOut(false);
    setBootDone(false);
    const t1 = window.setTimeout(() => setBootPhase(2), 800);
    const t2 = window.setTimeout(() => setBootPhase(3), 2200);
    const t3 = window.setTimeout(() => setBootPhase(4), 3400);
    return () => { window.clearTimeout(t1); window.clearTimeout(t2); window.clearTimeout(t3); };
  }, [game.id]);

  const dismissTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const dismissBoot = useCallback(async () => {
    if (fadingOut || bootDone) return;
    setFadingOut(true);
    try {
      const target = rootRef.current ?? document.documentElement;
      if (!document.fullscreenElement && 'requestFullscreen' in target) {
        await target.requestFullscreen();
      }
    } catch {  }
    dismissTimer.current = setTimeout(() => setBootDone(true), 500);
  }, [fadingOut, bootDone]);

  useEffect(() => () => { if (dismissTimer.current) window.clearTimeout(dismissTimer.current); }, []);

  const handleExit = useCallback(() => {
    router.push('/daydream/games');
  }, [router]);

  
  useEffect(() => {
    if (bootPhase < 4 || bootDone || fadingOut) return undefined;
    const handler = () => { dismissBoot(); };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [bootPhase, bootDone, fadingOut, dismissBoot]);

  const accent      = game.color;
  const stageBottom = isLandscape ? LANDSCAPE_MIN_STAGE_BOTTOM : MIN_STAGE_BOTTOM_CLEARANCE;
  const physicsConfig = useMemo<{ gravity: GravityPreset; friction: number }>(
    () => ({ gravity: 'earth', friction: 0.5 }),
    [],
  );

  return (
    <div
      ref={rootRef}
      style={{ position: 'fixed', inset: 0, width: '100vw', height: '100dvh', overflow: 'hidden', background: '#000' }}
    >
      
      <div
        className="de-immersive-game-stage"
        style={{
          position: 'absolute',
          top: 0, left: 0, right: 0,
          bottom: `max(var(--de-hud-bottom, ${DEFAULT_HUD_BOTTOM}), ${stageBottom})`,
          background: '#000',
        }}
      >
        {cartridgeError ? (
          <div style={{
            height: '100%', display: 'grid', placeItems: 'center',
            background: 'linear-gradient(180deg, #1a0505 0%, #0a0202 100%)',
            color: '#fca5a5', padding: 24, textAlign: 'center',
          }}>
            <div style={{ display: 'grid', gap: 12, maxWidth: 420 }}>
              <div style={{ fontSize: 28 }}>⚠️</div>
              <div style={{ fontSize: 16, fontWeight: 800, color: '#f8fbff' }}>Cartridge Error</div>
              <div style={{ fontSize: 13, lineHeight: 1.6 }}>{cartridgeError}</div>
            </div>
          </div>
        ) : (
          
          
          
          <GameRuntime
            cartridge={cartridge}
            physicsConfig={physicsConfig}
          />
        )}
      </div>

      
      {!bootDone && (
        <div
          role="presentation"
          onPointerDown={bootPhase >= 3 ? dismissBoot : undefined}
          onClick={bootPhase >= 3 ? dismissBoot : undefined}
          style={{
            position: 'absolute', inset: 0, zIndex: 40, background: '#000',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            cursor: bootPhase >= 4 ? 'pointer' : 'default',
            animation: fadingOut ? 'de-boot-fade-out 0.5s ease forwards' : undefined,
          }}
        >
          
          {bootPhase === 1 && (
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 20, animation: 'de-fade-in 0.4s ease forwards' }}>
              <div style={{ position: 'relative', width: 130, height: 130, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <div style={{ position: 'absolute', inset: -20, borderRadius: '50%', border: `2px solid ${accent}`, animation: 'de-glow-ring-a 1.6s ease-in-out infinite' }} />
                <div style={{ position: 'absolute', inset: -10, borderRadius: '50%', border: `1px solid ${accent}`, animation: 'de-glow-ring-b 1.6s ease-in-out infinite 0.4s' }} />
                <div style={{ fontSize: 76, lineHeight: 1, color: accent, textShadow: `0 0 48px ${accent}, 0 0 80px ${accent}44`, animation: 'de-hex-pulse 1.6s ease-in-out infinite' }}>⬡</div>
              </div>
            </div>
          )}

          
          {bootPhase === 2 && (
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 14, textAlign: 'center' }}>
              <div style={{ fontSize: 56, lineHeight: 1, animation: 'de-emoji-pop 0.45s cubic-bezier(0.34,1.56,0.64,1) forwards' }}>{game.emoji}</div>
              <div style={{ fontSize: 'clamp(36px, 7vw, 58px)', fontWeight: 900, letterSpacing: '0.10em', color: '#f8fbff', textTransform: 'uppercase', animation: 'de-sweep-in 0.5s cubic-bezier(0.2,0,0,1) 0.05s both' }}>GAMEENGIN</div>
              <div style={{ fontSize: 13, fontWeight: 600, letterSpacing: '0.26em', color: 'rgba(220,235,255,0.50)', textTransform: 'uppercase', animation: 'de-sweep-in-sub 0.5s cubic-bezier(0.2,0,0,1) 0.22s both' }}>by DREAMengin</div>
            </div>
          )}

          
          {(bootPhase === 3 || bootPhase === 4) && (
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 18, textAlign: 'center', padding: '0 28px', animation: 'de-fade-in 0.4s ease forwards' }}>
              <div style={{ fontSize: 52, lineHeight: 1 }}>{game.emoji}</div>
              <div style={{ fontSize: 'clamp(26px, 5.5vw, 52px)', fontWeight: 900, letterSpacing: '-0.03em', color: '#f8fbff', lineHeight: 1.1 }}>{game.label}</div>
              <div style={{ display: 'inline-flex', alignItems: 'center', padding: '4px 16px', borderRadius: 999, background: `${accent}1f`, border: `1px solid ${accent}55`, color: accent, fontSize: 11, fontWeight: 800, letterSpacing: '0.20em', textTransform: 'uppercase' }}>
                {game.category}
              </div>
              {bootPhase === 4 && (
                <div style={{ marginTop: 12, fontSize: 13, fontWeight: 700, letterSpacing: '0.18em', textTransform: 'uppercase', color: 'rgba(220,235,255,0.52)', animation: 'de-blink 1.3s ease-in-out infinite' }}>
                  Press any button to start
                </div>
              )}
            </div>
          )}

          
          <button
            type="button"
            onClick={(e) => { e.stopPropagation(); dismissBoot(); }}
            style={{
              position: 'absolute', bottom: 24, right: 24,
              fontSize: 11, fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase',
              color: 'rgba(220,235,255,0.32)', padding: '6px 13px', borderRadius: 8,
              background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)',
              cursor: 'pointer',
            }}
          >
            Skip →
          </button>
        </div>
      )}

      
      {isLandscape && (
        <div aria-hidden="true" style={{ position: 'absolute', left: 0, right: 0, bottom: 0, height: LANDSCAPE_MIN_STAGE_BOTTOM, background: '#000', zIndex: 0 }} />
      )}

      
      
      {bootDone && (
        <div style={{ position: 'absolute', left: 0, right: 0, bottom: 0, zIndex: 50 }}>
          <GameRemote
            embedded
            gameLabel={game.label}
            playHref={buildGameLaunchHref(game.id, { play: true })}
            onExit={handleExit}
          />
        </div>
      )}
    </div>
  );
}
