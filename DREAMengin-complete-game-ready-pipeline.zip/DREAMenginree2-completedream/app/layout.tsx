import '@/styles/globals.css';
import '@/styles/view-transitions.css';
import '@/styles/dream-shell.css';
import CommandPaletteMount from '@/components/dream.CommandPaletteMount';
import GlobalOverlays from '@/components/dream.GlobalOverlays';
import OfflineRuntimeBootstrap from '@/components/offline/dream.OfflineRuntimeBootstrap';
import OfflineStatusPill from '@/components/offline/dream.OfflineStatusPill';
import ThemeApplicator from '@/components/dream.ThemeApplicator';
import CartridgeRegistryBootstrap from '@/components/gameengin/dream.CartridgeRegistryBootstrap';
import GodTierProvider from '@/components/providers/dream.GodTierProvider';
import ThemeProvider from '@/components/providers/dream.ThemeProvider';
import DualRuntimeContainer from '@/components/runtime/dream.DualRuntimeContainer';
import { DreamSystemProvider } from '@/dreamdmbar/runtime/DreamSystemContext';
import { OSProvider } from '@/engine/os/OSContext';
import { CustomizeModeProvider } from '@/components/ui-system/CustomizeModeContext';
import '@/styles/home-dream.css';
import type { Metadata, Viewport } from 'next';
import localFont from 'next/font/local';
import { Suspense } from 'react';









const spaceGrotesk = localFont({
  src: '../fonts/Space_Grotesk/SpaceGrotesk-VariableFont_wght.ttf',
  variable: '--font-space-grotesk',
  display: 'swap',
});

const cormorant = localFont({
  src: '../fonts/Cormorant_Garamond/CormorantGaramond-VariableFont_wght.ttf',
  variable: '--font-cormorant',
  display: 'swap',
});

const dreamr = localFont({
  src: '../fonts/Plus_Jakarta_Sans/PlusJakartaSans-VariableFont_wght.ttf',
  variable: '--font-dreamr',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'DREAMengin - Your creative home',
  description: 'Build your profile, projects, content, shop, messages, and creative tools in one connected space.',
  icons: {
    icon: '/logo-icon.png',
    apple: '/logo-icon.png',
  },
  
  manifest: '/manifest.webmanifest',
};

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 5,
  userScalable: true,
  viewportFit: 'cover',
  themeColor: [
    { media: '(prefers-color-scheme: light)', color: '#dce8f8' },
    { media: '(prefers-color-scheme: dark)',  color: '#020818' },
  ],
};

export default function RootLayout({ children }: {children: React.ReactNode}) {
  return (
    <html
      lang="en"
      className={`${spaceGrotesk.variable} ${cormorant.variable} ${dreamr.variable} scroll-smooth`}
      data-theme="dream-ice"
      suppressHydrationWarning
    >
      <body
        className="antialiased dream-bg"
        style={{ fontFamily: 'var(--font-space-grotesk, "Space Grotesk", system-ui, sans-serif)' }}
      >
        <ThemeProvider>
          <OfflineRuntimeBootstrap />
          <ThemeApplicator />
          <Suspense><GodTierProvider /></Suspense>
          <OSProvider>
            <CustomizeModeProvider>
              <DreamSystemProvider>
                <CartridgeRegistryBootstrap />
                <DualRuntimeContainer>
                  <main role="main" aria-label="Main content">{children}</main>
                  <GlobalOverlays />
                  <OfflineStatusPill />
                  <Suspense><CommandPaletteMount /></Suspense>
                </DualRuntimeContainer>
              </DreamSystemProvider>
            </CustomizeModeProvider>
          </OSProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
