import { createServerClient } from '@/supabase/server/serverClient';
import { safeGetUser } from '@/supabase/client/safeGetUser';
import { redirect } from 'next/navigation';
import { connection } from 'next/server';
import FeedSettingsClient from './dream.FeedSettingsClient';



export const metadata = { title: 'Feed Settings – Dreamengin' };

export default async function FeedSettingsPage( ){
  await connection();
  const supabase = await createServerClient();
  const user = await safeGetUser(supabase);
  if (!user) redirect('/login');

  return <FeedSettingsClient />;
}
