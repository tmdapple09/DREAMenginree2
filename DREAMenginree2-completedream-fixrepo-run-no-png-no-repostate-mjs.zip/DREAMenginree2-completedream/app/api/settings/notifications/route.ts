import { createServerClient } from '@/supabase/server/serverClient';
import { safeGetUser } from '@/supabase/client/safeGetUser';
import type { SupabaseClient } from '@supabase/supabase-js';
import { NextRequest, NextResponse } from 'next/server';
import { toErrorMessage } from '@/utils/index';

/**
 * app/api/settings/notifications/route.ts
 *
 * GET  /api/settings/notifications  — Returns the authenticated user's notification settings
 * POST /api/settings/notifications  — Upserts notification settings into the settings table
 *
 * Data is stored in the JSONB `data` column under the `notifications` key in
 * the existing `settings` table (initial schema migration, user_id PK + RLS).
 *
 * Security (AXIOM 4):
 *   - auth.uid() = user_id enforced by RLS on the settings table
 *   - Requires authenticated user; returns 401 otherwise
 */

export async function GET( ): Promise<NextResponse> {
  const supabase = await createServerClient();
  const user = await safeGetUser(supabase);
  if (!user) {
    return NextResponse.json({ ok: false, error: 'Unauthorized' }, { status: 401 });
  }

  const db = supabase as SupabaseClient;

  const { data, error } = await db
    .from('settings')
    .select('data')
    .eq('user_id', user.id)
    .maybeSingle();

  if (error) {
    return NextResponse.json({ ok: false, error: toErrorMessage(error) }, { status: 500 });
  }

  const notifications = (data?.data as Record<string, unknown>)?.notifications ?? null;
  return NextResponse.json({ ok: true, notifications });
}

export async function POST(req: NextRequest): Promise<NextResponse> {
  const supabase = await createServerClient();
  const user = await safeGetUser(supabase);
  if (!user) {
    return NextResponse.json({ ok: false, error: 'Unauthorized' }, { status: 401 });
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, error: 'Invalid JSON' }, { status: 400 });
  }

  if (!body || typeof body !== 'object') {
    return NextResponse.json({ ok: false, error: 'Invalid settings object' }, { status: 400 });
  }

  const db2 = supabase as SupabaseClient;

  // Fetch existing settings first to merge
  const { data: existing } = await db2
    .from('settings')
    .select('data')
    .eq('user_id', user.id)
    .maybeSingle();

  const currentData = (existing?.data as Record<string, unknown>) ?? {};
  const merged = { ...currentData, notifications: body };

  const { error: upsertError } = await db2
    .from('settings')
    .upsert({ user_id: user.id, data: merged }, { onConflict: 'user_id' });

  if (upsertError) {
    return NextResponse.json({ ok: false, error: upsertError.message }, { status: 500 });
  }

  return NextResponse.json({ ok: true });
}
