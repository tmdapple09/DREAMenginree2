'use client';

/**
 * dream.hud.GameHUD.tsx
 *
 * DREAMengin GameHUD — shared HUD shell for all playable Dreams.
 *
 * Routes the control surface by MobileHudMode:
 *   mode === 'controller' → GameController (dual-stick full overlay)
 *   mode === 'joystick'   → GameRemote (d-pad / single-stick)
 *   mode === 'buttons'    → GameRemote (button-only ring)
 *   undefined             → GameRemote (default)
 *
 * Architecture: ARCHITECTURE.md §16 (GameEngin) + §20 (GameRemote)
 * Law: LAW.md — GameEngin owns the HUD surface. Cartridge-specific HUDs
 * belong inside cartridges; this is the shared control surface contract.
 */

import GameController from '@/components/games/dream.GameController';
import GameRemote from '@/components/games/dream.remote.GameRemote';
import type { MobileHudMode } from '@/lib/games/mobileControls';

export interface GameHUDProps {
  gameLabel: string;
  gameEmoji?: string;
  playHref?: string;
  /** Control surface mode. 'controller' = premium dual-analog overlay. */
  mode?: MobileHudMode;
  onExit: () => void;
}

/**
 * GameHUD — universal game HUD shell for the GameEngin pipeline.
 *
 * When mode === 'controller', the full dual-analog GameController overlay
 * renders: left stick for movement (jump on thumb-lift), right stick for
 * aim/look (tap to shoot, hold to auto-fire), 8-button ring for actions.
 *
 * For all other modes, GameRemote provides the embedded control surface:
 * d-pad ring, button set, pause/menu, standard game actions.
 */
export default function GameHUD({ gameLabel, gameEmoji, playHref, mode, onExit }: GameHUDProps) {
  if (mode === 'controller') {
    return (
      <GameController
        gameLabel={gameLabel}
        onExit={onExit}
      />
    );
  }

  return (
    <GameRemote embedded gameLabel={gameLabel} gameEmoji={gameEmoji} playHref={playHref} onExit={onExit} />
  );
}
