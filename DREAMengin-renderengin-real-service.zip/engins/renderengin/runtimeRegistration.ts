import { registerRuntimeEngin } from '@/engine/engin-runtime/EnginRuntimeRegistry';
import { RenderEnginRuleSet, RENDER_ENGIN_ID, RENDER_INTENT_TYPES } from './core';

export const RenderEnginRuntimeRegistration = registerRuntimeEngin({
  id: RENDER_ENGIN_ID,
  name: 'Render',
  route: '/engines/render',
  daydreamHref: '/engines/render',
  ruleSet: RenderEnginRuleSet,
  capabilityId: RENDER_ENGIN_ID,
  workflowSurfaces: ['DreamDMBar', 'HomeDream', 'DreamSpace', 'Daydream', 'ContentEngin', 'GameEngin', 'CodeEngin', 'LabEngin'],
  intentTypes: RENDER_INTENT_TYPES,
  handoffs: ['content.export.glb.preview', 'game.cartridge.mesh.preview', 'code.shader.preview', 'lab.simulation.mesh.preview'],
  metadata: {
    canonicalId: RENDER_ENGIN_ID,
    ownershipBoundary: 'Render is a shared rendering service used by Engins; Core Engine owns state, auth, transport, lifecycle, snapshots, and sync.',
    browserRequirement: 'Client-only WebGPU service surface with compatibility negotiation and non-WebGPU fallback messaging.',
  },
});
