# Libindex patch

Add these files to the repo:

- `scripts/lib-index.mjs`
- `.github/workflows/lib-index.yml`
- `Libindex.md` (generated snapshot from the uploaded repo)

What it does:

- scans `lib/`
- lists every lib file
- lists exports
- lists project/package imports
- lists which files outside `lib/` import each lib file
- groups files into canonical DREAMengin buckets
- marks review-needed files without deleting anything

The GitHub Action runs the script with plain Node:

```bash
node scripts/lib-index.mjs
```

No package.json change is required.
