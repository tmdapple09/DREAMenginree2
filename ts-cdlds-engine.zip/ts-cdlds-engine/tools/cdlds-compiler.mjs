#!/usr/bin/env node
import ts from 'typescript';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import process from 'node:process';

const args = parseArgs(process.argv.slice(2));
const root = path.resolve(args.root ?? process.cwd());
const out = path.resolve(args.out ?? path.join(root, 'cdlds-artifact'));
const MAX_FILE_BYTES = Number(args['max-file-bytes'] ?? 2_000_000);

const excludedDirNames = new Set([
  '.git','.github','.idea','.vscode','.cache','.next','.nuxt','.turbo',
  'node_modules','dist','build','out','coverage','target','vendor','generated',
  'docs','doc','documentation','examples','example','samples','sample',
  'tests','test','__tests__','spec','specs','fixtures','fixture','mocks','mock',
  'benchmarks','benchmark','.venv','venv','__pycache__'
]);
const sourceExts = new Set(['.ts','.tsx','.mts','.cts','.js','.jsx','.mjs','.cjs']);
const excludedNamePatterns = [
  /(?:^|[._-])(test|tests|spec|specs|fixture|fixtures|mock|mocks)(?:[._-]|$)/i,
  /\.d\.ts$/i, /\.min\.[cm]?js$/i, /\.generated\./i
];

class CFGBuilder {
  constructor(sf, prefix) { this.sf = sf; this.prefix = prefix; this.nodes = []; this.n = 0; }
  node(kind, ast, extra = {}) {
    const pos = this.sf.getLineAndCharacterOfPosition(ast.getStart(this.sf));
    const n = { id: `${this.prefix}#${this.n++}`, kind, fileLine: pos.line + 1, fileColumn: pos.character + 1,
      source: text(ast, this.sf), next: null, alternate: null, guard: null, effects: [], ...extra };
    this.nodes.push(n); return n;
  }
  buildStatement(stmt, next) {
    if (!stmt) return next;
    if (ts.isBlock(stmt)) {
      let cursor = next;
      for (let i = stmt.statements.length - 1; i >= 0; i--) cursor = this.buildStatement(stmt.statements[i], cursor);
      return cursor;
    }
    if (ts.isIfStatement(stmt)) {
      const n = this.node('branch', stmt, { guard: text(stmt.expression,this.sf), next: null, alternate: null });
      n.next = this.buildStatement(stmt.thenStatement, next);
      n.alternate = stmt.elseStatement ? this.buildStatement(stmt.elseStatement, next) : next;
      return n.id;
    }
    if (ts.isWhileStatement(stmt) || ts.isDoStatement(stmt)) {
      const expr = stmt.expression;
      const n = this.node('branch', stmt, { guard: text(expr,this.sf), next: null, alternate: next });
      n.next = this.buildStatement(stmt.statement, n.id);
      return n.id;
    }
    if (ts.isForStatement(stmt)) {
      const branch = this.node('branch', stmt, { guard: stmt.condition ? text(stmt.condition,this.sf) : 'true', next: null, alternate: next });
      let loopBack = branch.id;
      if (stmt.incrementor) loopBack = this.node('effect', stmt.incrementor, { effects: [text(stmt.incrementor,this.sf)], next: branch.id }).id;
      branch.next = this.buildStatement(stmt.statement, loopBack);
      if (stmt.initializer) return this.node('effect', stmt.initializer, { effects: [text(stmt.initializer,this.sf)], next: branch.id }).id;
      return branch.id;
    }
    if (ts.isForOfStatement(stmt) || ts.isForInStatement(stmt)) {
      const n = this.node('opaque-loop', stmt, { guard: 'external:iterator_has_next', effects: [text(stmt,this.sf)], next, alternate: next });
      return n.id;
    }
    if (ts.isReturnStatement(stmt)) return this.node('return', stmt, { effects: stmt.expression ? [`__return = (${text(stmt.expression,this.sf)})`] : ['__return = undefined'], next }).id;
    if (ts.isThrowStatement(stmt)) return this.node('throw', stmt, { effects: [`__throw = (${text(stmt.expression,this.sf)})`], next }).id;
    if (ts.isVariableStatement(stmt)) return this.node('effect', stmt, { effects: stmt.declarationList.declarations.map(d => declarationEffect(d,this.sf)), next }).id;
    if (ts.isExpressionStatement(stmt)) return this.node('effect', stmt, { effects: [text(stmt.expression,this.sf)], next }).id;
    if (ts.isBreakStatement(stmt) || ts.isContinueStatement(stmt)) return this.node('control', stmt, { effects: [`external:${stmt.kind === ts.SyntaxKind.BreakStatement ? 'break' : 'continue'}`], next }).id;
    if (ts.isTryStatement(stmt) || ts.isSwitchStatement(stmt) || ts.isLabeledStatement(stmt) || ts.isWithStatement(stmt))
      return this.node('opaque-control', stmt, { effects: [text(stmt,this.sf)], next }).id;
    return this.node('effect', stmt, { effects: [text(stmt,this.sf)], next }).id;
  }
}


fs.rmSync(out, { recursive: true, force: true });
fs.mkdirSync(out, { recursive: true });

const files = discover(root).filter(isSourceFile);
if (files.length === 0) fail('No application TypeScript/JavaScript source files found.');

const configPath = ts.findConfigFile(root, ts.sys.fileExists, 'tsconfig.json');
let options = {
  allowJs: true,
  checkJs: false,
  noEmit: true,
  skipLibCheck: true,
  target: ts.ScriptTarget.ES2022,
  module: ts.ModuleKind.NodeNext,
  moduleResolution: ts.ModuleResolutionKind.NodeNext,
  jsx: ts.JsxEmit.Preserve,
  allowSyntheticDefaultImports: true
};
let configDiagnostics = [];
if (configPath) {
  const read = ts.readConfigFile(configPath, ts.sys.readFile);
  if (read.error) configDiagnostics.push(read.error);
  else {
    const parsed = ts.parseJsonConfigFileContent(read.config, ts.sys, path.dirname(configPath), options, configPath);
    options = { ...parsed.options, ...options, noEmit: true, allowJs: true };
    configDiagnostics.push(...parsed.errors);
  }
}

const host = ts.createCompilerHost(options, true);
const program = ts.createProgram({ rootNames: files, options, host });
const checker = program.getTypeChecker();
const diagnostics = [...configDiagnostics, ...ts.getPreEmitDiagnostics(program)].map(normalizeDiagnostic);

const model = {
  schema: 'cdlds.typescript.semantic-ir.v1',
  generator: { name: 'ts-cdlds-engine', version: '1.0.0', typescript: ts.version },
  repository: { root: '.', sourceFileCount: 0, diagnosticsCount: diagnostics.length },
  semantics: {
    state: ['programCounter','environment','returnValue','thrown','halted','trace'],
    discrete: 'AST-derived statement and control-flow transitions',
    continuous: 'Explicit empty vector field unless source annotations provide one',
    unresolved: 'Represented as opaque effects or external calls; never silently discarded'
  },
  files: [], functions: [], diagnostics
};

for (const sf of program.getSourceFiles()) {
  const abs = path.resolve(sf.fileName);
  if (!abs.startsWith(root + path.sep) || sf.isDeclarationFile || !files.includes(abs)) continue;
  const rel = slash(path.relative(root, abs));
  const bytes = fs.readFileSync(abs);
  model.files.push({ path: rel, bytes: bytes.length, sha256: sha256(bytes), parseDiagnostics: sf.parseDiagnostics.map(normalizeDiagnostic) });
  extractFunctions(sf, rel, checker, model.functions);
}
model.repository.sourceFileCount = model.files.length;
model.files.sort((a,b)=>a.path.localeCompare(b.path));
model.functions.sort((a,b)=>a.id.localeCompare(b.id));

validateModel(model);
fs.writeFileSync(path.join(out, 'model.json'), stableJson(model));
fs.writeFileSync(path.join(out, 'diagnostics.json'), stableJson(diagnostics));
fs.writeFileSync(path.join(out, 'engine.mjs'), runtimeSource(), { mode: 0o755 });
fs.writeFileSync(path.join(out, 'README.md'), readme(model));
fs.writeFileSync(path.join(out, 'manifest.sha256'), manifest(out));
console.log(`Generated ${model.functions.length} function systems from ${model.files.length} source files.`);

function extractFunctions(sf, rel, checker, sink) {
  let anonymous = 0;
  function visit(node, owner = '') {
    if (isFunctionLikeWithBody(node)) {
      const name = functionName(node, ++anonymous);
      const qualified = owner ? `${owner}.${name}` : name;
      const id = `${rel}::${qualified}@${sf.getLineAndCharacterOfPosition(node.getStart(sf)).line + 1}`;
      const builder = new CFGBuilder(sf, id);
      const entry = builder.node('entry', node, { label: qualified, next: null });
      const exit = builder.node('halt', node, { label: `${qualified}:halt`, next: null });
      const bodyEntry = builder.buildStatement(node.body, exit.id);
      entry.next = bodyEntry;
      const symbol = node.name ? checker.getSymbolAtLocation(node.name) : undefined;
      let signature = 'unknown';
      try {
        const sig = checker.getSignatureFromDeclaration(node);
        if (sig) signature = checker.signatureToString(sig, node, ts.TypeFormatFlags.NoTruncation);
      } catch {}
      sink.push({
        id, file: rel, name: qualified, signature,
        parameters: (node.parameters ?? []).map(p => p.name.getText(sf)),
        entry: entry.id, exit: exit.id, nodes: builder.nodes,
        source: text(node, sf), exported: hasModifier(node, ts.SyntaxKind.ExportKeyword),
        symbol: symbol?.getName() ?? null
      });
      owner = qualified;
    }
    ts.forEachChild(node, child => visit(child, owner));
  }
  visit(sf);
}


function runtimeSource() { return `#!/usr/bin/env node
import fs from 'node:fs'; import path from 'node:path'; import vm from 'node:vm'; import process from 'node:process';
const base=path.dirname(new URL(import.meta.url).pathname); const model=JSON.parse(fs.readFileSync(path.join(base,'model.json'),'utf8'));
const [cmd='help',...rest]=process.argv.slice(2); const opt=parse(rest);
if(cmd==='validate'){validate(); console.log('valid');}
else if(cmd==='list'){for(const f of model.functions) console.log(f.id);}
else if(cmd==='show'){const f=find(opt.function??rest[0]); console.log(JSON.stringify(f,null,2));}
else if(cmd==='run'||cmd==='trace'||cmd==='smoke'){runCommand(cmd,opt);}
else {console.log('Commands: validate | list | show --function ID | run --function ID [--input JSON] [--max-steps N] | trace ... | smoke');}
function runCommand(cmd,o){const funcs=cmd==='smoke'?model.functions:[find(o.function)]; let failed=0; for(const f of funcs){try{const r=run(f,o); if(cmd!=='smoke') console.log(JSON.stringify(r,null,2));}catch(e){failed++; console.error(f.id+': '+e.message);}} if(failed)process.exitCode=1;}
function run(f,o){const nodes=new Map(f.nodes.map(n=>[n.id,n])); const env=Object.assign(Object.create(null),safeJson(o.input??'{}')); env.__return=undefined; env.__throw=undefined; const trace=[]; let pc=f.entry,steps=0,max=Number(o['max-steps']??10000); while(pc&&steps++<max){const n=nodes.get(pc); if(!n)throw Error('Missing node '+pc); trace.push({step:steps,pc:n.id,kind:n.kind,line:n.fileLine}); if(n.kind==='halt')break; if(n.kind==='branch'){pc=truth(evalExpr(n.guard,env))?n.next:n.alternate;continue;} for(const effect of n.effects??[])apply(effect,env); if(n.kind==='return'||n.kind==='throw'){pc=f.exit;continue;} pc=n.next;} if(steps>=max)throw Error('Step limit exceeded'); return {function:f.id,steps,halted:pc===f.exit,returnValue:env.__return,thrown:env.__throw,environment:plain(env),trace:o.trace||process.argv[2]==='trace'?trace:undefined};}
function evalExpr(src,env){if(String(src).startsWith('external:'))return false; try{return new vm.Script('('+src+')').runInNewContext(env,{timeout:50});}catch{return env['$unknown:'+src]??false;}}
function apply(src,env){if(String(src).startsWith('external:')){env['$effect:'+src]=(env['$effect:'+src]??0)+1;return;} try{new vm.Script(src).runInNewContext(env,{timeout:50});}catch(e){env['$opaque:'+src]={error:e.message};}}
function find(id){if(!id)throw Error('--function is required'); const exact=model.functions.find(f=>f.id===id); const matches=exact?[exact]:model.functions.filter(f=>f.id.includes(id)); if(matches.length!==1)throw Error('Function selector matched '+matches.length+' functions'); return matches[0];}
function validate(){if(model.schema!=='cdlds.typescript.semantic-ir.v1')throw Error('schema'); for(const f of model.functions){const ids=new Set(f.nodes.map(n=>n.id)); if(!ids.has(f.entry)||!ids.has(f.exit))throw Error('entry/exit '+f.id); for(const n of f.nodes)for(const k of ['next','alternate'])if(n[k]&&!ids.has(n[k]))throw Error('edge '+n.id);}}
function parse(a){const o={};for(let i=0;i<a.length;i++){if(a[i].startsWith('--')){const k=a[i].slice(2);o[k]=a[i+1]&&!a[i+1].startsWith('--')?a[++i]:true;}}return o;} function safeJson(s){try{return JSON.parse(s)}catch{throw Error('Invalid --input JSON')}} function truth(v){return !!v} function plain(v){return JSON.parse(JSON.stringify(v,(k,x)=>typeof x==='bigint'?String(x):x))}
`; }

function validateModel(m) {
  const functionIds = new Set();
  for (const f of m.functions) {
    if (functionIds.has(f.id)) fail(`Duplicate function id: ${f.id}`);
    functionIds.add(f.id);
    const ids = new Set(f.nodes.map(n => n.id));
    if (!ids.has(f.entry) || !ids.has(f.exit)) fail(`Invalid entry/exit in ${f.id}`);
    for (const n of f.nodes) for (const k of ['next','alternate']) if (n[k] && !ids.has(n[k])) fail(`Dangling ${k} edge in ${n.id}`);
  }
}
function declarationEffect(d,sf){const name=d.name.getText(sf);return d.initializer?`${name} = (${text(d.initializer,sf)})`:`${name} = undefined`;}
function isFunctionLikeWithBody(n){return (ts.isFunctionDeclaration(n)||ts.isMethodDeclaration(n)||ts.isConstructorDeclaration(n)||ts.isGetAccessorDeclaration(n)||ts.isSetAccessorDeclaration(n)||ts.isFunctionExpression(n)||ts.isArrowFunction(n))&&!!n.body;}
function functionName(n,i){if(n.name)return n.name.getText(); if(ts.isConstructorDeclaration(n))return 'constructor'; return `anonymous_${i}`;}
function hasModifier(n,k){return !!n.modifiers?.some(m=>m.kind===k);}
function text(n,sf){return n.getText(sf).replace(/\r\n/g,'\n');}
function normalizeDiagnostic(d){const out={category:ts.DiagnosticCategory[d.category],code:d.code,message:ts.flattenDiagnosticMessageText(d.messageText,'\n')};if(d.file&&d.start!==undefined){const p=d.file.getLineAndCharacterOfPosition(d.start);out.file=slash(path.relative(root,d.file.fileName));out.line=p.line+1;out.column=p.character+1;}return out;}
function discover(dir){const result=[];for(const ent of fs.readdirSync(dir,{withFileTypes:true})){if(ent.isSymbolicLink())continue;if(ent.isDirectory()&&excludedDirNames.has(ent.name.toLowerCase()))continue;const p=path.join(dir,ent.name);if(ent.isDirectory())result.push(...discover(p));else if(ent.isFile())result.push(p);}return result;}
function isSourceFile(p){const rel=slash(path.relative(root,p));const base=path.basename(p);if(excludedNamePatterns.some(r=>r.test(base)))return false;if(!sourceExts.has(path.extname(p).toLowerCase()))return false;const s=fs.statSync(p);return s.size>0&&s.size<=MAX_FILE_BYTES&&!rel.startsWith(slash(path.relative(root,out))+'/');}
function sha256(v){return crypto.createHash('sha256').update(v).digest('hex');}
function slash(v){return v.split(path.sep).join('/');}
function stableJson(v){return JSON.stringify(sort(v),null,2)+'\n';}
function sort(v){if(Array.isArray(v))return v.map(sort);if(v&&typeof v==='object'){return Object.fromEntries(Object.keys(v).sort().map(k=>[k,sort(v[k])]))}return v;}
function manifest(dir){return fs.readdirSync(dir).filter(x=>x!=='manifest.sha256').sort().map(x=>`${sha256(fs.readFileSync(path.join(dir,x)))}  ${x}`).join('\n')+'\n';}
function parseArgs(a){const o={};for(let i=0;i<a.length;i++){if(!a[i].startsWith('--'))continue;const k=a[i].slice(2);o[k]=a[i+1]&&!a[i+1].startsWith('--')?a[++i]:true;}return o;}
function readme(m){return `# Executable CDLDS artifact\n\nGenerated from ${m.repository.sourceFileCount} application source files and ${m.functions.length} function-level control systems. TypeScript diagnostics are retained and do not abort generation.\n\n## Commands\n\n\`node engine.mjs validate\`\n\`node engine.mjs list\`\n\`node engine.mjs show --function SELECTOR\`\n\`node engine.mjs run --function SELECTOR --input '{"x":1}'\`\n\`node engine.mjs trace --function SELECTOR --input '{"x":1}'\`\n\`node engine.mjs smoke --max-steps 10000\`\n\nThe runtime executes the generated control graph. Effects that cannot execute in the isolated VM are retained as opaque effects in the engine state rather than discarded.\n`;}
function fail(msg){console.error(msg);process.exit(1);}
