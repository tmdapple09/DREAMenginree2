// SURFACE: dreamsurface.EnginesMusicArrange  (framework-mandated basename: page.tsx)
import ArrangePanel from '@/components/engines/music/panels/dream.panel.ArrangePanel';
import { EnginAppShell, EnginNavBar } from '@/components/engines/shared';
import { isDevBypassActive } from '@/lib/dev-bypass';
import { createServerClient } from '@/lib/supabase/server';
import { safeGetUser } from '@/lib/supabase/safeGetUser';
import { redirect } from 'next/navigation';
import { connection } from 'next/server';

export const metadata = { title: 'Arrangement – StarMakerEngin', description: 'Visual arrangement view.' };

const ACCENT = '#a855f7';
const NAV_ITEMS = [
  { href: '/engines/music',         label: 'DAW',     emoji: '🎛️' },
  { href: '/engines/music/studio',  label: 'Studio',  emoji: '🎙️' },
  { href: '/engines/music/arrange', label: 'Arrange', emoji: '🎼' },
  { href: '/engines/music/library', label: 'Library', emoji: '📂' },
];

export default async function MusicArrangePage( ){
  await connection();
  const supabase = await createServerClient();
  const user = await safeGetUser(supabase);
  if (!user && !isDevBypassActive()) redirect('/login');

  return (
    <EnginAppShell
      engineName="StarMakerEngin"
      engineEmoji="🎵"
      accentColor={ACCENT}
      backHref="/daydream/music"
      backLabel="Music Daydream"
      nav={<EnginNavBar items={NAV_ITEMS} accentColor={ACCENT} />}
    >
      <ArrangePanel />
    </EnginAppShell>
  );
}